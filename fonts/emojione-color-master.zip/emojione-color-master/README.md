# EmojiOne Color

EmojiOne Color is an open source color font in OpenType-SVG format built by Adobe
from the [EmojiOne 2.3] artwork designed by Denis Denz and produced by Rick Moby.
The font contains all of the emoji in Unicode 9.0 and includes support for ZWJ
sequences, skin tone diversity, and country flag emoji.

[EmojiOne 2.3]: https://www.emojione.com/emoji/v2

